# ShellSkill-API
REST API for ShellSkill.io
