exports.system_messages = {
    legacy: {
        USER_NOT_FOUND: 404,
        STATUS200: 200,
    },
    warning: {

    },
    error: {
    },
    success: {
        SIGNIN_SUCCESS: 1000
    }
}